const fontFiles = [
    { name: 'dialog', url: 'fonts/dialog.xml', imageUrl: 'fonts/dialog.png' },
];
